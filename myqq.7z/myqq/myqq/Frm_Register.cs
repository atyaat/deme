﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace myqq
{
    public partial class Frm_Register : Form
    {
        public Frm_Register()
        {
            InitializeComponent();
        }
        MysqlRead mysql = new MysqlRead();
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (txtID.Text.Trim() == "" || txtID.Text.Length > 8)
            {
                MessageBox.Show("账号输入有误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtID.Focus();
                return;
            }
            if (txtPwd.Text.Trim() == "")
            {
                MessageBox.Show("请输入密码！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPwd.Focus();
                return;
            }
            if (txtPwdAgain.Text.Trim() == "")
            {
                MessageBox.Show("请输入确认密码！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPwdAgain.Focus();
                return;
            }
            if (txtPwdAgain.Text.Trim() != txtPwd.Text.Trim())
            {
                MessageBox.Show("两次输入的密码不一样！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPwdAgain.Focus();
                return;
            }

            int ID = 0;
            string message;
            string sql = "INSERT INTO tb_user (ID,pwd) VALUES ("+txtID.Text.Trim()+",'"+txtPwd.Text.Trim()+"'";
            
            int result = mysql.MySqlReturnRows(sql);
            if (result == 1)
            {
                message = "创建成功！";
            }
            else
            {
                message = "创建失败，请重试！";
            }
            DataOperator.connection.Close();
            MessageBox.Show(message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
