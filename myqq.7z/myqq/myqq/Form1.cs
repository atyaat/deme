﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myqq
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
       
        MysqlRead mysql = new MysqlRead();
        private void Login_Load(object sender, EventArgs e)
        {

        }
        private bool ValidateInpot()
        {
            if (txtID.Text.Trim() == "" || int.Parse(txtID.Text.Trim()) > 65535) 
            {
                MessageBox.Show("请输入登入账号", "登入提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtID.Focus();
                return false;
            }
            else if (txtID.Text.Length>7 && txtpwd.Text.Trim() =="")
            {
                MessageBox.Show("请输入登入密码", "登入提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtpwd.Focus();
                return false;
            }
            return true;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || (e.KeyChar == '\r') || (e.KeyChar == '\b'))
            {
                e.Handled = false;   //在控件中显示该字符
            }
            else
            {
                e.Handled = true;  // 取消显示
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateInpot())
            {
                string sql = "SELECT COUNT(*) FROM tb_user where ID ='"+int.Parse(txtID.Text.Trim())+"' AND pwd ='"+txtpwd.Text.Trim()+"'";
                int num = mysql.MySqlReturnRows(sql);
                if (num == 1)
                {
                    PublicClass.loginID = int.Parse(txtID.Text.Trim());
                    if (cboxRemember.Checked)
                    {
                        mysql.MySqlReturnRows("UPDATE tb_user SET Remember = 1 WHERE ID = "+ int.Parse(txtID.Text.Trim()) + ""); //记住密码
                        if (cboxAutoLogin.Checked)
                        {
                            mysql.MySqlReturnRows("UPDATE tb_user SET Remember = 1 WHERE ID = "+ int.Parse(txtID.Text.Trim()) + "");//自动登录
                        }
                    }
                    else
                    {
                        mysql.MySqlReturnRows("UPDATE tb_user SET Remember = 0 WHERE ID = " + int.Parse(txtID.Text.Trim()) + "");
                        mysql.MySqlReturnRows("UPDATE tb_user SET Remember = 0 WHERE ID = " + int.Parse(txtID.Text.Trim()) + "");
                    }
                    frmMain frmmaim = new frmMain();
                    frmmaim.Show();
                    this.Visible = false;

                }
                else
                {
                    MessageBox.Show("输入的用户名或密码有误！", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void txtpwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                button1_Click(sender, e);
            }
        }

        private void cboxRemember_CheckedChanged(object sender, EventArgs e)
        {
            if (!cboxRemember.Checked) //判断记住密码是否选中
            {
                cboxAutoLogin.Checked = false;  //自动登录设置为未选中
            }
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            ValidateInpot();
            
            //string sql = "";
            //string[] zz = new string[5];
            //mysql.MySqlOnlyRow(sql,ref zz);
            //if (int.Parse(zz[0])==1) //判断是否有这个用户
            //{
            //    if (Convert.ToInt32(zz[2]) == 1) //判断是否记住密码
            //    {
            //        cboxRemember.Checked = true;
            //        txtpwd.Text = zz[1];
            //        if (Convert.ToInt32(zz[3]) == 1) // 判断是否自动登录
            //        {
            //            cboxAutoLogin.Checked = true;
            //            button1_Click(sender, e);
            //        }
            //    }
            //}

        }

        private void linkLabReg_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Frm_Register frmRegister = new Frm_Register();
            frmRegister.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }
    }
}
