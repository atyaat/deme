Connector/Net 6.8  Release Notes
------------------------------------

Welcome to the release notes for Connector/Net 6.8

What's new in 6.8
--------------------

- Entity Framework 6 support.


Be sure and check the documentation for more information on these new features.